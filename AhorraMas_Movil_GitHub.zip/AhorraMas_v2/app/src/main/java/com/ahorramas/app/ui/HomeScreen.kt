package com.ahorramas.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ahorramas.app.viewmodel.ProductViewModel

@Composable
fun HomeScreen(
    viewModel: ProductViewModel,
    onProducts: () -> Unit,
    onAdd: () -> Unit,
    onScan: () -> Unit
) {
    val products by viewModel.products.collectAsState()
    val saved = products.sumOf { it.saving }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("AhorraMás") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) {
                Icon(Icons.Default.Add, contentDescription = "Añadir")
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Tu ahorro", style = MaterialTheme.typography.headlineMedium)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("Ahorro acumulado", style = MaterialTheme.typography.labelLarge)
                    Text("%.2f €".format(saved), style = MaterialTheme.typography.displaySmall)
                    Text("${products.size} productos guardados")
                }
            }

            Button(onClick = onScan, Modifier.fillMaxWidth()) {
                Icon(Icons.Default.QrCodeScanner, null)
                Spacer(Modifier.width(8.dp))
                Text("Escanear producto")
            }

            OutlinedButton(onClick = onProducts, Modifier.fillMaxWidth()) {
                Icon(Icons.Default.ShoppingCart, null)
                Spacer(Modifier.width(8.dp))
                Text("Mis productos")
            }
        }
    }
}
