package com.ahorramas.app.repository

import com.ahorramas.app.data.Product
import com.ahorramas.app.data.ProductDao

class ProductRepository(private val dao: ProductDao) {
    fun getProducts() = dao.getProducts()
    suspend fun addProduct(product: Product) = dao.insert(product)
    suspend fun deleteProduct(product: Product) = dao.delete(product)
}
