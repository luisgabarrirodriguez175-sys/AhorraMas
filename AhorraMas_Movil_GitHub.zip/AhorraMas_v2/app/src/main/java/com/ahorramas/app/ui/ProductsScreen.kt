package com.ahorramas.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ahorramas.app.viewmodel.ProductViewModel

@Composable
fun ProductsScreen(viewModel: ProductViewModel, onBack: () -> Unit) {
    val products by viewModel.products.collectAsState()

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Mis productos", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        if (products.isEmpty()) {
            Text("No tienes productos todavía.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products, key = { it.id }) { product ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(16.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(product.name, style = MaterialTheme.typography.titleMedium)
                                if (product.barcode != null) Text("EAN: ${product.barcode}")
                                Text("Antes: %.2f €".format(product.normalPrice))
                                Text("Ahora: %.2f €".format(product.foundPrice))
                                Text("Ahorro: %.2f €".format(product.saving))
                            }
                            TextButton(onClick = { viewModel.deleteProduct(product) }) {
                                Text("Borrar")
                            }
                        }
                    }
                }
            }
        }
        TextButton(onClick = onBack) { Text("Volver") }
    }
}
