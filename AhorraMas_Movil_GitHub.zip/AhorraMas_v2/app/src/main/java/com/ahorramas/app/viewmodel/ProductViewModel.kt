package com.ahorramas.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ahorramas.app.data.Product
import com.ahorramas.app.repository.ProductRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProductViewModel(private val repository: ProductRepository) : ViewModel() {
    val products = repository.getProducts().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )

    fun addProduct(name: String, barcode: String?, normal: Double, found: Double) {
        viewModelScope.launch {
            repository.addProduct(
                Product(name = name, barcode = barcode, normalPrice = normal, foundPrice = found)
            )
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch { repository.deleteProduct(product) }
    }
}
