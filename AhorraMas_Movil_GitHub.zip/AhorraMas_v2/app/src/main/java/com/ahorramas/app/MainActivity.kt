package com.ahorramas.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.room.Room
import com.ahorramas.app.data.AppDatabase
import com.ahorramas.app.repository.ProductRepository

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(
            applicationContext, AppDatabase::class.java, "ahorramas.db"
        ).build()

        setContent {
            MaterialTheme {
                Surface { AhorraMasApp(ProductRepository(db.productDao())) }
            }
        }
    }
}
