package com.ahorramas.app

import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ahorramas.app.repository.ProductRepository
import com.ahorramas.app.ui.*
import com.ahorramas.app.viewmodel.ProductViewModel
import com.ahorramas.app.viewmodel.ProductViewModelFactory

@Composable
fun AhorraMasApp(repository: ProductRepository) {
    val vm: ProductViewModel = viewModel(factory = ProductViewModelFactory(repository))
    var screen by remember { mutableStateOf("home") }
    var scannedBarcode by remember { mutableStateOf<String?>(null) }

    when (screen) {
        "home" -> HomeScreen(
            vm,
            onProducts = { screen = "products" },
            onAdd = { screen = "add" },
            onScan = { screen = "scanner" }
        )
        "products" -> ProductsScreen(vm) { screen = "home" }
        "add" -> AddProductScreen(vm, scannedBarcode) {
            scannedBarcode = null
            screen = "home"
        }
        "scanner" -> BarcodeScannerScreen(
            onDetected = {
                scannedBarcode = it
                screen = "add"
            },
            onBack = { screen = "home" }
        )
    }
}
