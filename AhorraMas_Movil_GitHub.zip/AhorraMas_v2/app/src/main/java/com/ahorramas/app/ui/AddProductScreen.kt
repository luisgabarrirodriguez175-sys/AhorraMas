package com.ahorramas.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ahorramas.app.viewmodel.ProductViewModel

@Composable
fun AddProductScreen(
    viewModel: ProductViewModel,
    barcode: String?,
    onDone: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var normal by remember { mutableStateOf("") }
    var found by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Nuevo producto", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        if (barcode != null) {
            Text("Código: $barcode", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = name, onValueChange = { name = it },
            Modifier.fillMaxWidth(), label = { Text("Nombre") }
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = normal, onValueChange = { normal = it },
            Modifier.fillMaxWidth(), label = { Text("Precio habitual (€)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = found, onValueChange = { found = it },
            Modifier.fillMaxWidth(), label = { Text("Precio encontrado (€)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                val n = normal.replace(",", ".").toDoubleOrNull()
                val f = found.replace(",", ".").toDoubleOrNull()
                if (name.isNotBlank() && n != null && f != null) {
                    viewModel.addProduct(name.trim(), barcode, n, f)
                    onDone()
                }
            },
            Modifier.fillMaxWidth(),
            enabled = name.isNotBlank() && normal.isNotBlank() && found.isNotBlank()
        ) { Text("Guardar producto") }

        TextButton(onClick = onDone) { Text("Cancelar") }
    }
}
