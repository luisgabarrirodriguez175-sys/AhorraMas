package com.ahorramas.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val barcode: String? = null,
    val normalPrice: Double,
    val foundPrice: Double
) {
    val saving: Double get() = (normalPrice - foundPrice).coerceAtLeast(0.0)
}
