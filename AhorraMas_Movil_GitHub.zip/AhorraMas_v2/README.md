# AhorraMás v2

MVP Android en Kotlin + Jetpack Compose + Room.

Incluye:
- Interfaz renovada con Material 3.
- Base local de productos.
- Cálculo de ahorro.
- Escáner de códigos de barras con CameraX + ML Kit.
- Permiso de cámara.
- Código de barras asociado al producto.

Abrir la carpeta en Android Studio y sincronizar Gradle.
