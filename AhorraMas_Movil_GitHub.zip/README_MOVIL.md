# AhorraMás — versión para trabajar SOLO desde el móvil

Esta versión está preparada para compilarse en la nube mediante GitHub Actions.
No necesitas Android Studio ni un ordenador para generar el APK de prueba.

## Pasos desde el móvil

1. Crea/inicia sesión en GitHub.
2. Crea un repositorio nuevo, por ejemplo `AhorraMas`.
3. Sube TODOS los archivos y carpetas de este proyecto.
4. Entra en la pestaña **Actions** del repositorio.
5. Abre **Compilar AhorraMás**.
6. Pulsa **Run workflow**.
7. Espera a que termine el proceso.
8. En la ejecución terminada, busca **Artifacts** y descarga `AhorraMas-debug-apk`.
9. Descomprime el archivo descargado y toca el APK para instalarlo.

## Importante

- El APK generado es una versión de prueba (debug).
- Para publicar en Google Play necesitaremos preparar una versión release firmada (AAB), configurar la clave de firma de forma segura y completar Google Play Console.
- No compartas nunca tu clave de firma ni contraseñas en el repositorio.
